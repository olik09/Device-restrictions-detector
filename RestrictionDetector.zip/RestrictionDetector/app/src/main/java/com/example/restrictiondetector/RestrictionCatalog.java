package com.example.restrictiondetector;

import android.os.UserManager;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Enumerates every DISALLOW_* / ENSURE_* user-restriction constant exposed by
 * android.os.UserManager on this device, via reflection on the public API
 * surface only. This stays valid across OS versions without hardcoding a
 * list that goes stale -- new restrictions added by a given OS/OEM show up
 * automatically.
 *
 * This class is read-only: it never calls any method that sets, clears, or
 * otherwise mutates a restriction.
 */
public final class RestrictionCatalog {

    private RestrictionCatalog() {}

    /** Returns the restriction key constants (e.g. "no_factory_reset") sorted alphabetically. */
    public static List<String> allKnownRestrictions() {
        List<String> result = new ArrayList<>();
        for (Field f : UserManager.class.getFields()) {
            if (!Modifier.isStatic(f.getModifiers())) continue;
            if (f.getType() != String.class) continue;
            String name = f.getName();
            if (!name.startsWith("DISALLOW_")) continue;
            try {
                Object value = f.get(null);
                if (value instanceof String) {
                    result.add((String) value);
                }
            } catch (IllegalAccessException ignored) {
                // Field not accessible on this OS version; skip it.
            }
        }
        Collections.sort(result);
        return result;
    }
}
