package com.example.restrictiondetector;

import android.content.Context;
import android.os.Bundle;
import android.os.UserManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Reports which user restrictions are currently ACTIVE vs INACTIVE for the
 * calling app's user, using only the public UserManager API that is
 * available to any installed app (no root / no Xposed required for this
 * part). This reflects the restriction set after enforcement by whatever
 * Device Owner / Profile Owner / parental-control app is installed --
 * it does not identify which admin set which restriction (see
 * RestrictionLoggerHook for that, which does require the LSPosed module to
 * be active).
 */
public final class RestrictionScanner {

    public static final class Report {
        public final List<String> active = new ArrayList<>();
        public final List<String> inactive = new ArrayList<>();
    }

    public static Report scan(Context context) {
        UserManager um = (UserManager) context.getSystemService(Context.USER_SERVICE);
        Report report = new Report();
        if (um == null) {
            return report;
        }

        Bundle restrictions = um.getUserRestrictions();
        for (String key : RestrictionCatalog.allKnownRestrictions()) {
            if (restrictions.getBoolean(key, false)) {
                report.active.add(key);
            } else {
                report.inactive.add(key);
            }
        }
        return report;
    }
}
