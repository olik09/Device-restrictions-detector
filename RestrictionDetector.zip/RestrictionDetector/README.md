# Restriction Detector

A **read-only** LSPosed module + companion app that reports which Android
`UserManager` / `DevicePolicyManager` restrictions are currently active on a
device, and (when the module is enabled for `system_server`) logs which
admin component sets or clears which restriction, in real time.

It does **not** remove, bypass, or weaken any restriction. There is no
toggle anywhere in the code that calls `setUserRestriction(..., false)` or
any equivalent clearing API. Every hook in `RestrictionLoggerHook` only logs
`before`/`after` state — it never calls `param.setResult(...)`, never
rewrites `param.args`, and never suppresses the original method call. This
is meant as the diagnostic half of a two-part project: use this to see
exactly how policy enforcement currently surfaces on your test device, then
build detection/integrity-checking (the actual "protection") on top of that
picture.

## How it works

**Layer 1 — app-side, no root/Xposed needed** (`RestrictionScanner.java`)
Calls the public `UserManager.getUserRestrictions()` API from the
companion app's own process. Any app can do this; it reflects the combined
restriction set already enforced on that user. Tap "Scan restrictions" in
the app to see ACTIVE vs INACTIVE for every `DISALLOW_*` constant found via
reflection on `UserManager` (so it stays current automatically on future
Android versions — nothing is hardcoded).

**Layer 2 — LSPosed hook into system_server** (`RestrictionLoggerHook.java`)
When enabled for "Android system" (`system_server`) in LSPosed Manager and
the device is rebooted, this hooks every overload of
`setUserRestriction` / `clearUserRestriction` found on
`DevicePolicyManagerService` and logs each call (caller args + return
value) to the Xposed log, visible in LSPosed Manager → Logs. It also does a
one-time full dump of active/inactive restrictions at boot completion.

## Build — from a phone only, no laptop needed

This project includes `.github/workflows/build.yml`, so GitHub's servers
build the APK for you; your phone just needs a browser.

1. Download `RestrictionDetector.zip` and unzip it (any file manager /
   "Files" app with a zip-extract option works), or keep it zipped — GitHub
   accepts a zip upload directly in step 3.
2. On github.com (mobile browser is fine), create a free account if you
   don't have one, then tap **+ → New repository**. Name it anything, e.g.
   `restriction-detector`, and create it (public or private, either works).
3. On the new repo's page, tap **Add file → Upload files**, then upload
   either the unzipped folder contents or drag in the whole zip (GitHub
   will offer to extract it). Commit the upload.
4. Go to the **Actions** tab of the repo. A "Build debug APK" run should
   already be queued (it triggers on every push). Tap it, wait for it to
   finish (a few minutes).
5. Once it shows a green check, scroll to **Artifacts** at the bottom of
   that run page and tap `RestrictionDetector-debug-apk` to download it —
   it's the finished, installable APK in a zip.
6. On your phone, open the downloaded zip, extract `app-debug.apk`, tap it,
   and allow installation from this source if prompted. This is a debug
   build (self-signed by Gradle automatically), so no separate signing step
   is needed.
7. Install an LSPosed Manager if you don't have one, enable the
   Restriction Detector module there, and scope it to **Android system
   (system_server)** for Layer 2. Layer 1 (the in-app scan button) works
   without any scoping.
8. Reboot for the system_server hook to take effect.
9. Open the app and tap "Scan restrictions" for the static snapshot, or
   check LSPosed Manager → Logs for the live `[RestrictionDetector]` entries
   showing restriction-change calls as they happen.

### Alternative: AIDE app

If you'd rather build on-device without GitHub, the **AIDE** app (Android
IDE, available on the Play Store) can open this project folder directly and
build an APK locally on your phone, no cloud step required. Behavior is
otherwise identical — AIDE just replaces Android Studio.

## Project layout

```
app/src/main/java/com/example/restrictiondetector/
  RestrictionCatalog.java    - reflects over UserManager for all DISALLOW_* keys
  RestrictionScanner.java    - app-side active/inactive scan (public API only)
  RestrictionLoggerHook.java - system_server hook, logs restriction changes
  MainActivity.java          - simple UI for the app-side scan
app/src/main/assets/xposed_init - declares RestrictionLoggerHook as the entry point
```

## Notes on API/compatibility

This uses the classic `de.robv.android.xposed` API (`compileOnly
'de.robv.android.xposed:api:82'`), which LSPosed fully supports and which
has by far the best documentation and example coverage for hooking
arbitrary methods by reflection (needed here since
`DevicePolicyManagerService`'s exact method signatures vary across AOSP
versions/OEMs). If you specifically want the newer `io.github.libxposed`
("Api100"/"Api102"-style) module API instead, the same logic ports over —
the main change is the entry-point class implementing
`io.github.libxposed.api.XposedModule` instead of
`IXposedHookLoadPackage`, and hook registration going through that module's
`XposedInterface` rather than `XposedBridge`. Happy to port it if you tell
me which LSPosed/libxposed API version you're targeting.
